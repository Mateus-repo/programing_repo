<?php
session_start();
require_once 'includes/db.php';
require_once 'includes/auth.php';

$_SESSION = array();

session_destroy();

header('Location: home.php');
exit();
?>